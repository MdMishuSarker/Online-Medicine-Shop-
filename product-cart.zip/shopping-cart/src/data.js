const data = {
  products: [
    {
      id: '1',
      name: 'Napa Extra',
      price: 300,
      image: 'https://emedi.com.bd/wp-content/uploads/2020/09/Napa-Extra-Tablet.jpg',
    },
    {
      id: '2',
      name: 'Napa Syrup',
      price: 80,
      image: 'https://cdn1.arogga.com/eyJidWNrZXQiOiJhcm9nZ2EiLCJrZXkiOiJtZWRpY2luZVwvMjFcLzIxMTU5LU5hcGEtMTIwbWctNW1sLWVhcWIucG5nIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxMDAwLCJoZWlnaHQiOjEwMDAsImZpdCI6Im91dHNpZGUifSwib3ZlcmxheVdpdGgiOnsiYnVja2V0IjoiYXJvZ2dhIiwia2V5IjoibWlzY1wvd20ucG5nIiwiYWxwaGEiOjkwfX19',
    },
    {
      id: '3',
      name: 'Alatrol',
      price: 350,
      image: 'https://emedi.com.bd/wp-content/uploads/2020/09/Alatrol-Tablet.jpg',
    },
    {
      id: '4',
      name: 'Condom',
      price: 120,
      image: 'https://www.bigbasket.com/media/uploads/p/xxl/40232845_2-durex-extra-thin-condom-for-men-high-quality-bubblegum-flavoured.jpg',
    },
    {
      id: '5',
      name: 'Baby Diapers',
      price: 120,
      image: 'https://m.media-amazon.com/images/I/71LBikW2MwS._AC_SL1500_.jpg',
    },
    {
      id: '6',
      name: "Mom's Care",
      price: 120,
      image: 'https://shineskinbd.com/wp-content/uploads/2021/06/Pax-Moly-Stretch-Marks-Cream2.jpg',
    },



  ],

};
export default data;
